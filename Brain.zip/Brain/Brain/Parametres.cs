﻿namespace Brain
{
    public class ParametresReveil
    {
        public bool IsActive { get; set; }
        public bool BigSleeper { get; set; }
        public int AlarmMode { get; set; }
       
    }

    public class Ring
    {
        public bool IsRinging{ get; set; }
        public string AlarmHour { get; set; }
     
    }

    public class Infos
    {
        public string Traffic{ get; set; }
        public string Meteo { get; set; }

    }

}


