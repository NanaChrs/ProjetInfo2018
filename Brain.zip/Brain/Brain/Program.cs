﻿using Constellation;
using Constellation.Package;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Brain
{
    public partial class Program : PackageBase
    {
        [StateObjectLink("*", "Parametres_reveil")]
        public StateObjectNotifier ParametresServeur { get; set; }


        

        static void Main(string[] args)
        {
            PackageHost.Start<Program>(args);
        }

        public override void OnStart()
        {
            PackageHost.WriteInfo("Package starting - IsRunning: {0} - IsConnected: {1}", PackageHost.IsRunning, PackageHost.IsConnected);

            Task.Factory.StartNew(async () =>
            {
                while (PackageHost.IsRunning)
                {
                    var data = new ParametresReveil()
                    {
                        IsActive = false,
                        BigSleeper = false,
                        AlarmMode = 0,
                    };
                    PackageHost.PushStateObject("paramètresRéveil", data);
                    
                    await Task.Delay(PackageHost.GetSettingValue<Int32>("Interval"));
                }
                
            });
            PackageHost.WriteInfo(ParametresReveil);

            /*

            if (this.ParametresServeur.ToString() == "")
            {
                var myData = new ParametresReveil()
                {
                IsActive = false,
                BigSleeper = false,
                AlarmMode = 0,
                };
                PackageHost.PushStateObject("Parametres_reveil", myData);
                this.ParametresServeur.ValueChanged += ParametresServeur_ValueChanged;
                
            }
            */
            //Après avoir récupéré des paramètres, on s'abonne au changements du SO
            this.ParametresServeur.ValueChanged += ParametresServeur_ValueChanged;
            //Initialisation à partir des paramètres...
            //Sinon attente
        }
        
        private void ParametresServeur_ValueChanged(object sender, StateObjectChangedEventArgs e)
        {
            if (e.NewState.DynamicValue.IsActive != e.OldState.DynamicValue.IsActive)//Si changement d'état
            {
                if(e.NewState.DynamicValue.IsActive ==true)
                {
                    PackageHost.WriteInfo("Le réveil est maintenant actif");
                }
                else
                {
                    PackageHost.WriteInfo("Le réveil n'est plus actif :(");
                }
            }
            if (e.NewState.DynamicValue.AlarmMode != e.OldState.DynamicValue.AlarmMode)//Si changement d'état
            {
                if (e.NewState.DynamicValue.AlarmMode == 2)
                {
                    PackageHost.WriteInfo("Le réveil est maintenant en mode calendar");
                }
                else
                {
                    PackageHost.WriteInfo("J'ai changé de mode mais jsp c'est lequel :/");
                }
            }

        }

        //on start, le brain récupère tous les paramètres du state object (ou sinon les met en valeur par défaut), et on met un Valuechanged sur ce state object
        //on affiche un message a chaque fois que la valeur est modifiée


    }
}     
 







