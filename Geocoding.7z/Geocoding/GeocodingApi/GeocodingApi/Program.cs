﻿using Constellation;
using Constellation.Package;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;

namespace GeocodingApi
{
    public class Program : PackageBase
    {

        [MessageCallback]
        public static void Geocoding(string adress)
        {
            string APIkey = "AIzaSyB_oKCbvTHtGuIg0vbRsnqD9JgIQNOWMno";
            var Adresse = adress.Replace(" ", "+");
            var url = "https://maps.googleapis.com/maps/api/geocode/json?address=" + Adresse + "&key=" + APIkey;
            Console.WriteLine("Avant la boucle");
            using (WebClient webClient = new System.Net.WebClient())
            {
                Console.WriteLine("Boucle");
                WebClient n = new WebClient();
                var json = n.DownloadString(url);
                string valueOriginal = Convert.ToString(json);
                dynamic GPS = JsonConvert.DeserializeObject(json);
                Console.WriteLine(GPS);
                
                
            }
            
        }
        static void Main(string[] args)
        {
            PackageHost.Start<Program>(args);
        }

        public override void OnStart()
        {
            PackageHost.WriteInfo("Package starting - IsRunning: {0} - IsConnected: {1}", PackageHost.IsRunning, PackageHost.IsConnected);
            Geocoding("ISEN Lille");
        }
    }
}
